<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class KicksController extends Controller
{
    public function checkPregnancy(Request $request)
    {
        // Validate the incoming request data
        $data = $request->validate([
            'number_of_kicks' => 'required|integer',
            'start_hour' => 'required|date_format:H:i',
            'end_hour' => 'required|date_format:H:i|after:start_hour',
        ]);

        // Extract data from the validated request
        $numberOfKicks = $data['number_of_kicks'];
        $startHour = $data['start_hour'];
        $endHour = $data['end_hour'];

        // Define thresholds for normality
        $normalKicksThreshold = 10; // Number of kicks considered normal
        $normalKicksDuration = 60; // Duration in minutes considered normal for kicks to occur

        // Calculate duration between start and end hours
        $start = strtotime($startHour);
        $end = strtotime($endHour);
        $durationInMinutes = ($end - $start) / 60;

        // Check if the number of kicks is within the normal range and if the duration is sufficient
        $isNormal = ($numberOfKicks >= $normalKicksThreshold && $durationInMinutes >= $normalKicksDuration);

        // Provide a message indicating the result
        $message = $isNormal ? 'Pregnancy is normal' : 'Pregnancy might be abnormal. Please consult a doctor.';

        // Return the response
        return response()->json([
            'is_normal' => $isNormal,
            'message' => $message,
        ]);
    }
    // Controller method to handle the weight comparison
    public function compareWeight(Request $request)
    {
        // Validate incoming request
        $request->validate([
            'weight_before_pregnancy' => 'required|numeric',
            'current_weight' => 'required|numeric',
            'current_weight_date' => 'required|date',
        ]);

        // Get user inputs
        $weightBeforePregnancy = $request->input('weight_before_pregnancy');
        $currentWeight = $request->input('current_weight');
        $currentWeightDate = $request->input('current_weight_date');

        // Calculate normal weight (you need to implement this logic)
        $normalWeight = $this->calculateNormalWeight($weightBeforePregnancy);

        // Compare current weight with normal weight
        if ($currentWeight > $normalWeight) {
            $status = 'Higher than normal';
        } elseif ($currentWeight < $normalWeight) {
            $status = 'Less than normal';
        } else {
            $status = 'Normal';
        }

        // Return response
        return response()->json([
            'status' => $status,
            'normal_weight' => $normalWeight,
            'current_weight_date' => $currentWeightDate,
        ]);
    }
// Method to calculate the normal weight based on pre-pregnancy weight
    private function calculateNormalWeight($weightBeforePregnancy)
    {
        // Example: Assume a simple formula to calculate normal weight during pregnancy
        // You should replace this with a medically accurate formula or guidelines
        // This is just a placeholder and may not represent actual medical advice

        // Assuming a 0.5 kg (500 grams) increase per week is normal during pregnancy
        $normalWeightIncreasePerWeek = 0.5;

        // Assuming a pregnancy lasts for 40 weeks (standard gestation period)
        $pregnancyWeeks = 40;

        // Calculate the total expected weight gain during pregnancy
        $expectedWeightGain = $normalWeightIncreasePerWeek * $pregnancyWeeks;

        // Calculate the normal weight based on pre-pregnancy weight and expected weight gain
        $normalWeight = $weightBeforePregnancy + $expectedWeightGain;

        return $normalWeight;
    }

}
